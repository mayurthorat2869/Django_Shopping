from django.shortcuts import render,redirect
from django.http import HttpResponse
# Create your views here.
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.hashers import make_password, check_password     # This is For Hide Password to admin
from .models import *


def index(request):
    if request.method=="GET":
        cart = request.session.get('cart')
        if not cart:                     # If you have login get method through index page cart not available then request to session cart
            request.session['cart'] = {}

        products = None
        categories = Category.objects.all()
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.objects.filter(category=categoryID)
        else:
            products = Product.objects.all()
        print('You Are :',request.session.get('email'))
        d = {'products':products, 'categories':categories}
        return render(request,'index.html',d)

    else:                                         # Else means post method
        product = request.POST['product']
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity ==1:
                        cart.pop(product)   # Here suppose you have one product in cart then this remove used pop
                    else:
                        cart[product] = quantity - 1   # Here suppose you have more than one cart then remove minus used
                else:
                    cart[product] = quantity + 1   # Adding Cart Used This
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart:',request.session['cart'])
        return redirect('index')

def Signup(request):
    if request.method=="GET":
        return render(request,'signup.html')
    else:
        if request.method=="POST":
            fname = request.POST['fname']
            lname = request.POST['lname']
            phone = request.POST['phone']
            email = request.POST['email']
            pwd = request.POST['pwd']
            # Validation:

            value = {
                'fname' : fname,
                'lname' : lname,
                'phone' : phone,
                'email' : email,
                'password': pwd
            }



            error_message = None

            if not fname:
                error_message = "First Name Required !!"
            elif len(fname)<3:
                    error_message = "First Name Must Be 4 char or more"
            elif not lname:
                error_message = "Last Name Required !!"
            elif len(lname)<4:
                    error_message = "First Name Must Be 4 char or more"
            elif not phone:
                error_message = "Phone Number Required !!"
            elif len(phone) < 5:
                error_message = "Phone number Must Be 4 char or more"

            # This Condition for email is allready exists or not filter customer email:
            elif Customer.objects.filter(email=email):
                error_message = "Email Address Allready Register"







            elif not pwd:
                error_message = "Password Required !!"
            elif len(pwd) < 4:
                error_message = "Password Must Be 4 char or more"

            # Saving:
            if not error_message:
                customer = Customer(fname=fname,lname=lname,phone=phone,email=email,password=pwd)
                customer.password = make_password(customer.password) # Means here hide the password to admin
                customer.save()
                return redirect('index')
            else:
                d = {'error':error_message,'values':value}
                return render(request,'signup.html',d)

def Login(request):
    if request.method=="GET":
        return render(request,'login.html')
    else:
        email = request.POST['email']
        password = request.POST['password']
        customer = Customer.get_customer_by_email(email)   # Calling method from models

        error_message = None
        if customer:
            flag = check_password(password,customer.password)
            if flag:
                request.session['customer'] = customer.id  # Here Save Customer id and email to session before redirect
                request.session['email']    = customer.email                                        # Because in which type of user check
                return redirect('index')
            else:
                error_message = "Email or Password is Invalid !!"
        else:
            error_message = "Email or Password is Invalid !!"

        return render(request,'login.html',{'error':error_message})

def Cart(request):
    if request.method=="GET":
        productId=list(request.session.get('cart').keys())   #Fetching product id list means keys
        products = Product.objects.filter(id__in=productId)
        print(products)
        return render(request,'cart.html',{'products':products})
    else:
        address = request.POST['address']
        phone = request.POST['phone']
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        productId = list(request.session.get('cart').keys())  # Fetching product id list means keys
        products = Product.objects.filter(id__in=productId)


        print(address, phone, customer, cart,products)
        return redirect('cart')

def Order(request):
    customer = request.session.get('customer')
    return render(request,'order.html')

def Logout(request):
    request.session.clear()
    return redirect('login')


