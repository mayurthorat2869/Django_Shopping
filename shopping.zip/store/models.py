from django.db import models
from datetime import *
# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category,on_delete=models.CASCADE,default=1)
    description = models.CharField(max_length=200)
    image = models.ImageField(upload_to='products/')

class Customer(models.Model):
    fname = models.CharField(max_length=60)
    lname = models.CharField(max_length=60)
    phone = models.CharField(max_length=11)
    email = models.EmailField()
    password = models.CharField(max_length=500)

    @staticmethod
    def get_customer_by_email(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return  False


class Order(models.Model):
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    price = models.IntegerField()
    address = models.CharField(max_length=200, default='')
    phone = models.CharField(max_length=12, default='')
    date = models.DateField(default=datetime.today)












