from django.contrib import admin
from django.urls import path
from . import views
from .middlewares.auth import simple_middleware


urlpatterns = [
    path('',views.index,name='index'),
    path('signup/',views.Signup,name='signup'),
    path('login/',views.Login,name='login'),
    path('cart/',simple_middleware(views.Cart),name='cart'),
    path('order/',simple_middleware(views.Order),name='order'),
    path('logout/',views.Logout,name='logout'),

]
